#!/usr/bin/env bash
set -u
printf '\n== RC1: VERIFICACION SIN MOVIMIENTO ==\n'
if ! command -v ros2 >/dev/null 2>&1; then
  echo 'ROS 2 no esta cargado. Ejecuta source /opt/ros/humble/setup.bash en esta terminal.'
  exit 1
fi
if [[ -z "${ROS_DOMAIN_ID:-}" ]]; then
 echo 'ATENCION: ROS_DOMAIN_ID no esta exportado; confirma el ID del laboratorio.'
else
 echo "ROS_DOMAIN_ID=${ROS_DOMAIN_ID} (confirma con responsable)"
fi
printf '\n-- Nodos --\n'; timeout 8 ros2 node list || true
printf '\n-- Topicos --\n'; timeout 8 ros2 topic list || true
printf '\n-- Odom tipo y publicadores --\n'; timeout 8 ros2 topic info /odom -v || true
printf '\n-- Odom una muestra --\n'; timeout 8 ros2 topic echo /odom --once || true
printf '\n-- EKF --\n'; timeout 8 ros2 node list | grep -i ekf || echo 'No se encontro EKF: verificar /odom_raw y consultar al docente.'
printf '\nNo se han publicado comandos de movimiento.\n'
