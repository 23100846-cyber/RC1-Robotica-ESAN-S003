# Inventario RC1 Parte E

- [ ] Cinta métrica + transportador + cinta para marcar centro y rumbo
- [ ] Batería robot y cargador; espacio 2 x 2 m + margen de 15 cm
- [ ] Acceso Wi-Fi/SSH a Raspberry Pi / contenedor ROS 2
- [ ] Docente o responsable presente y persona lista para parada manual
- [ ] `ROS_DOMAIN_ID`, `odom_topic` y comprobaciones de EKF documentados
- [ ] Giro de 90° con CSV, bag y medida exterior
- [ ] Recta 1D, 3 corridas con CSV, bag y cinta
- [ ] Cuadrado 3A, 1 corrida con CSV, bag y cierre cinta
- [ ] Cuadrado 3B, 3 corridas con CSV, bag y cierre cinta
- [ ] Tabla de cambios de ganancias: máximo 3 resintonizaciones, un parámetro por vez
- [ ] Tabla comparativa sim → real y gráficas
- [ ] Subir evidencias a GitHub y crear tag `v1.0-rc1` cuando la entrega esté completa
