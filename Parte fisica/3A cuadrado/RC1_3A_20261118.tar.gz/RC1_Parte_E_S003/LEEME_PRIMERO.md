# RC-1 · Parte E (robot real) · ESAN S003

**Objetivo:** ejecutar las pruebas reales de manera supervisada, registrar medidas externas y preparar evidencias. Basado en `RC1_Control_PID_2026-2.docx`, Partes E–F y Anexos C–F.

## Requisitos y preparación

- Robot con batería cargada; docente/técnico presente; piso nivelado con **2 × 2 m libres más 15 cm de margen**, sin objetos ni personas en el trayecto.
- Marcar el inicio con cinta (centro del robot y orientación); tener cinta métrica y transportador; una persona al teclado preparada para **Ctrl+C** y otra junto al robot para detenerlo de forma segura.
- **Primera comprobación con ruedas elevadas por un soporte seguro, hecha con supervisión:** verificar sentido de avance y giro antes de ponerlo en el piso. Si la dirección no concuerda, detenerse y consultar al responsable.
- Conectar PC y Raspberry Pi al entorno ROS 2 del grupo. Confirmar el `ROS_DOMAIN_ID` usado en el laboratorio. **No se presupone que el ID del simulador o del RC-0 sea correcto actualmente.**
- **No iniciar `yahboomcar_sim`** en la misma red/dominio durante la prueba real: podría publicar `/odom` o recibir `/cmd_vel` y falsear resultados.
- `cierre_real.py` basado en `/sim/pose` **no sirve para el robot real**; aquí la verdad de terreno viene de la cinta y el transportador.

## Organización de terminales

**Terminal 1: Raspberry Pi (SSH), bringup.** Con los datos reales facilitados por el laboratorio:

```bash
ssh <USUARIO_PI>@<IP_DE_LA_PI>
# Entrar al entorno ROS 2 de la Pi / contenedor indicado por el responsable
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=<DOMINIO_DEL_GRUPO>
ros2 launch capytown_esan bringup.launch.py
```

> Si `capytown_esan` vive dentro de un contenedor del RC-0, primero entrar al contenedor y cargar su `install/setup.bash` según el procedimiento del equipo. **No inventar** IP, usuario, dominio ni ruta del workspace. No uses este bloque hasta comprobarlos.

**Terminal 2: comprobaciones de ROS en el entorno que vea al robot.**

```bash
source /opt/ros/humble/setup.bash
# source <WORKSPACE_INSTALADO>/install/setup.bash  # si aplica
export ROS_DOMAIN_ID=<DOMINIO_DEL_GRUPO>
ros2 node list
ros2 topic list
ros2 topic hz /odom                   # salir con Ctrl+C
ros2 topic echo /odom --once
ros2 node list | grep -i ekf || true
ros2 topic info /odom -v
```

Si falta EKF o `/odom` no existe, verificar `/odom_raw` con el docente y usar `-p odom_topic:=/odom_raw` **solo tras comprobar** que ese es el tópico correcto. El nodo debe ver el mismo dominio y red que el bringup.

**Terminal 3: controlador, en carpeta que contenga `core_cuadrado.py`.**

```bash
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=<DOMINIO_DEL_GRUPO>
cd ~/scripts_pdi/scripts_pdi
# Ejecutar las pruebas abajo, una a la vez
```

**Terminal 4: registro de ROS bags** (desde el entorno que alcance los tópicos del robot). Antes de cada prueba:

```bash
source /opt/ros/humble/setup.bash
export ROS_DOMAIN_ID=<DOMINIO_DEL_GRUPO>
cd ~/RC1_Parte_E_S003/bags
ros2 bag record /odom /cmd_vel /tf -o rc1_real_giro_run1
```

Dejar el bag registrando durante el movimiento; al terminar la corrida presionar **Ctrl+C en Terminal 4** y esperar a que se guarde. Repetir con **nombres únicos**; los bags son carpetas que contienen archivos `.db3` o `.mcap` y metadatos. Si el robot usa `/odom_raw`, añadir ese tópico al bag.

## Secuencia exigida por el profesor

1. **Bringup + verificar `/odom`** y si existe EKF. Anotar frecuencia y tópicos en `logs/comprobaciones.txt`.
2. **Giro de 90°**, primero con velocidades suaves y supervisión. Medir ángulo externo; objetivo de rúbrica **error final ≤ 3°** (por confirmar en la cátedra). Comenzar con la configuración del simulador **solo como referencia** y reajustar si el robot real responde mal. Ejecutar después de la comprobación de giro con ruedas elevadas.
3. **Recta 1D:** tres corridas, desplazamiento virtual inicial `line_offset:=0.10`, sin `bias_w` artificial; medir desvío lateral final con cinta, objetivo **≤ 5 cm** (por confirmar); cada corrida lleva CSV y bag.
4. **Cuadrado de 2 × 2 m:** **3A una corrida** y **3B tres corridas**, medir cierre externo con cinta, registrar yaw con transportador. Objetivo **promedio de 3B ≤ 25 cm y menor que 3A** (por confirmar en cátedra).
5. Sintonizar cambiando **un solo parámetro por prueba, máximo tres resintonizaciones**, guardando cada configuración previa y la razón del cambio.

### Comandos de controlador (Terminal 3)

**Giro 90° — iniciar únicamente tras comprobaciones y aprobación del responsable:**

```bash
python3 cuadrado_controller.py --ros-args \
  -p experimento:=giro90 -p kp_yaw:=10.0 -p ki_yaw:=0.0 -p kd_yaw:=1.2 \
  -p linear_speed:=0.10 -p max_angular:=1.0 \
  -p log_csv:=$HOME/RC1_Parte_E_S003/csv/giro_run1.csv
```

**Recta 1D — ejecutar tres veces cambiando el sufijo `run1`/`run2`/`run3`:**

```bash
python3 cuadrado_controller.py --ros-args \
  -p experimento:=recta -p controlador:=pid \
  -p kp:=3.0 -p ki:=0.5 -p kd:=4.0 \
  -p line_offset:=0.10 -p bias_w:=0.0 \
  -p linear_speed:=0.10 -p max_angular:=1.0 \
  -p log_csv:=$HOME/RC1_Parte_E_S003/csv/recta_1d_run1.csv
```

**Cuadrado 3A — una vez; no utilizar lazo abierto si no se ha comprobado previamente el movimiento seguro:**

```bash
python3 cuadrado_controller.py --ros-args \
  -p experimento:=cuadrado_abierto -p side:=2.0 \
  -p linear_speed:=0.10 -p max_angular:=1.0 \
  -p log_csv:=$HOME/RC1_Parte_E_S003/csv/cuadrado_3a_run1.csv
```

**Cuadrado 3B — tres veces; renombrar `run1` a `run2` y `run3`:**

```bash
python3 cuadrado_controller.py --ros-args \
  -p experimento:=cuadrado -p side:=2.0 \
  -p kp:=3.0 -p ki:=0.0 -p kd:=4.0 \
  -p kp_yaw:=10.0 -p ki_yaw:=0.0 -p kd_yaw:=1.2 \
  -p bias_w:=0.0 -p linear_speed:=0.10 -p max_angular:=1.0 \
  -p log_csv:=$HOME/RC1_Parte_E_S003/csv/cuadrado_3b_run1.csv
```

> En lazo abierto, la distancia real puede depender de tiempos fijos; `side:=2.0` **no garantiza** que recorrerá exactamente 2 m con velocidad reducida. El profesor debe validar el ajuste de tiempos/velocidades del nodo antes del ensayo físico. Si algo no coincide, **no ejecutar lazo abierto** hasta revisarlo. Las ganancias del simulador no están validadas físicamente: bajar parámetros según indicaciones del docente si se observa inestabilidad.

### En caso de problema

- Si `/odom` no publica o cambia de manera extraña, **no mover el robot**; resolver conexión, dominio, origen odométrico y EKF.
- Si el robot avanza/gira al revés, vibra, se desvía demasiado, se sale del área o el bringup falla: **Ctrl+C inmediatamente**, detener el experimento y consultar al supervisor.
- Al ver `FIN`, presionar **Ctrl+C** en la Terminal 3, revisar que el CSV tenga filas válidas y **luego** detener el bag en la Terminal 4. No confundir el error de cierre impreso desde `/odom` con el cierre externo medido con cinta.
- Mantener las velocidades del primer ensayo en `0.10 m/s` y `1.0 rad/s` como máximos, y subirlas solo tras ensayo seguro autorizado.

## Registrar las medidas

Después de cada ensayo, medir y escribir directamente en `hoja_resultados_real.csv`:
`prueba`, `run`, `ganancias`, `cierre_odom_cm`, `cierre_cinta_cm`, `yaw_final_transportador_deg`, `desvio_lateral_cinta_cm`, `resultado`, `notas`.

Los campos sin medición se dejan vacíos. **Nunca poner cero si no se midió**.

## Gráficas y entrega

```bash
cd ~/scripts_pdi/scripts_pdi
python3 09_plot_csv.py ~/RC1_Parte_E_S003/csv/recta_1d_run1.csv --experimento recta
python3 09_plot_csv.py ~/RC1_Parte_E_S003/csv/giro_run1.csv --experimento giro90
python3 09_plot_csv.py ~/RC1_Parte_E_S003/csv/cuadrado_3b_run1.csv --experimento cuadrado --lado 2.0
```

Usar nombres equivalentes para todos los CSV. **Para la recta**, comprobar que la herramienta de gráficas descarte filas `FIN` posteriores a la primera. Mover los PNG a `plots/`. Evitar sobreescribir originales.

Entrega final (Parte F): `config/rc1_pid.yaml` con ganancias finales del simulador y del robot, `csv/hoja_resultados.csv`, CSV y gráficos, `bags/`, `sim_log.txt`, `rqt_graph.png`, README e **informe.pdf de una página**. El enunciado también pide tag `v1.0-rc1` en GitHub, y consultar con el profesor el nombre de repositorio/grupo.

**Las mediciones de simulador de este kit son referencias verificadas en nuestras pruebas previas, no predicciones de resultados físicos.**
