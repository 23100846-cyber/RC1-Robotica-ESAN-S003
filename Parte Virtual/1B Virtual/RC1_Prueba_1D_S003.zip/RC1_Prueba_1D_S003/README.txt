UNIVERSIDAD ESAN - ROBOTICA
RC-1 - PARTE B - PRUEBA 1D
SECCION S-003

CONTROL PID COMPLETO

Kp = 3.0
Ki = 0.5
Kd = 4.0
line_offset = 0.10 m
bias_w = 0.06 rad/s
noise = low

OBJETIVO:
Corregir la desviacion de una recta de 2 m
con un error lateral final <= 2 cm.

RESULTADOS:
===== PRUEBA 1D - PID COMPLETO =====
Kp: 3.0
Ki: 0.5
Kd: 4.0
Muestras originales: 2927
Muestras validas: 306
Duracion: 10.231 s
Error medio: 2.71 cm
Error maximo: 10.00 cm
Error final: 0.17 cm
Asentamiento: 5.86 s
Objetivo error final <= 2 cm: CUMPLIDO


COMPARACION:
1C (P+D): error final 2.12 cm.
1D (PID): error final 0.17 cm.

CONCLUSION:
La incorporacion de Ki redujo el error
persistente y permitio cumplir el objetivo.

Los datos corresponden al simulador,
no al carrito fisico.

Se conservan los CSV originales y limpios.
