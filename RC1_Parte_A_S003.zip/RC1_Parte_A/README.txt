UNIVERSIDAD ESAN - ROBOTICA
RC-1 CONTROL PID
PARTE A: CONOCER EL SIMULADOR
Seccion: S-003

ENTORNO:
Ubuntu 22.04, WSL 2, ROS 2 Humble
Simulador: yahboomcar_sim
Mundo: arena_rc1
Ruido: high

EVIDENCIAS:
sim_log.txt: topicos, odometria y parametros.
csv/sim_a.csv: posiciones estimadas y reales.
plots/sim_a.png: grafica de trayectorias.
logs/cierre_resultado.txt: cierre estimado y real.
logs/frenado.txt: comprobacion del frenado.
capturas/rqt_graph.png: grafo ROS.
scripts/cierre_real.py: registrador independiente.

NOTAS:
La frecuencia real medida consta en sim_log.txt.
El recorrido manual es aproximado.
cierre_real.py es una implementacion independiente,
no el archivo original del profesor.
