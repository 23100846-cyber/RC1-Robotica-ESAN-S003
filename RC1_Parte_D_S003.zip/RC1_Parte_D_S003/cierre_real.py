#!/usr/bin/env python3
"""Registro ROS 2 de /odom frente a /sim/pose para RC-1 (simulador).

Ejemplo:
    python3 cierre_real.py --csv exp3b_real.csv --png exp3b_real.png --lado 2.0
Iniciar antes del controlador. Terminar con Ctrl+C una vez que el robot se detenga.
Este archivo es una implementación independiente, NO el original de la cátedra.
"""
import argparse
import csv
import math
from pathlib import Path

import rclpy
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from rclpy.node import Node


def yaw(q):
    return math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z))


def relative_trajectory(points):
    x0, y0, angle0 = points[0]
    c, s = math.cos(angle0), math.sin(angle0)
    return [((x - x0) * c + (y - y0) * s,
             -(x - x0) * s + (y - y0) * c) for x, y, _ in points]


def accumulated_yaw(points):
    return math.degrees(sum(math.atan2(math.sin(b[2]-a[2]), math.cos(b[2]-a[2]))
                            for a, b in zip(points, points[1:])))


class Recorder(Node):
    def __init__(self, args):
        super().__init__('rc1_cierre_real')
        self.args = args
        self.odom = None
        self.truth = None
        self.rows = []
        self.t0 = None
        self.create_subscription(Odometry, '/odom', self.on_odom, 10)
        self.create_subscription(PoseStamped, '/sim/pose', self.on_truth, 10)
        self.create_timer(0.05, self.sample)
        self.get_logger().info('Registrando /odom y /sim/pose a ~20 Hz; Ctrl+C al finalizar.')

    def on_odom(self, msg):
        pose = msg.pose.pose
        self.odom = (pose.position.x, pose.position.y, yaw(pose.orientation))

    def on_truth(self, msg):
        pose = msg.pose
        self.truth = (pose.position.x, pose.position.y, yaw(pose.orientation))

    def sample(self):
        if self.odom is None or self.truth is None:
            return
        t = self.get_clock().now().nanoseconds * 1e-9
        if self.t0 is None:
            self.t0 = t
        self.rows.append((t - self.t0, *self.odom, *self.truth))

    def save(self):
        if not self.rows:
            print('Sin muestras: comprueba que existen /odom y /sim/pose y que usas el mismo ROS_DOMAIN_ID.')
            return
        output = Path(self.args.csv)
        output.parent.mkdir(parents=True, exist_ok=True)
        with output.open('w', newline='') as stream:
            writer = csv.writer(stream)
            writer.writerow(['t', 'odom_x', 'odom_y', 'odom_yaw', 'real_x', 'real_y', 'real_yaw'])
            writer.writerows([tuple(f'{v:.6f}' for v in row) for row in self.rows])
        odom = [row[1:4] for row in self.rows]
        real = [row[4:7] for row in self.rows]
        odom_xy = relative_trajectory(odom)
        real_xy = relative_trajectory(real)
        odom_close = 100 * math.hypot(*odom_xy[-1])
        real_close = 100 * math.hypot(*real_xy[-1])
        print(f'muestras: {len(self.rows)} ({self.rows[-1][0]:.1f} s)')
        print(f'cierre según /odom : {odom_close:.1f} cm yaw acumulado: {accumulated_yaw(odom):.1f} deg')
        print(f'cierre REAL        : {real_close:.1f} cm yaw acumulado: {accumulated_yaw(real):.1f} deg')
        print(f'CSV: {output}')
        if self.args.png:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            fig, ax = plt.subplots(figsize=(7, 7))
            ax.plot(*zip(*odom_xy), label='/odom (estimado)', linewidth=1.8)
            ax.plot(*zip(*real_xy), label='/sim/pose (real)', linewidth=1.8)
            side = self.args.lado
            ax.plot([0, side, side, 0, 0], [0, 0, side, side, 0], '--', label=f'Cuadrado ideal {side:g} m', color='gray')
            ax.scatter([0], [0], marker='o', label='Inicio')
            ax.set(xlabel='X relativa (m)', ylabel='Y relativa (m)', title='RC-1: odometría vs trayectoria real')
            ax.grid(alpha=.3)
            ax.axis('equal')
            ax.legend()
            png = Path(self.args.png)
            png.parent.mkdir(parents=True, exist_ok=True)
            fig.savefig(png, dpi=160, bbox_inches='tight')
            plt.close(fig)
            print(f'PNG: {png}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', required=True)
    parser.add_argument('--png', default='')
    parser.add_argument('--lado', type=float, default=2.0)
    args = parser.parse_args()
    rclpy.init()
    node = Recorder(args)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.save()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
