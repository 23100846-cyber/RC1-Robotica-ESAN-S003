UNIVERSIDAD ESAN - RC-1 - PARTE D - S003
Experimento 3: cuadrado 2 x 2 m, en simulador.
3A: lazo abierto; 3B: odometria + PID, bias_w=0.03;
3C: PID + Ki=0.5, bias_w=0.05.
Ganancias 3B/3C: linea Kp=3,Kd=4; giro Kp_yaw=10,Kd_yaw=1.2.
Por prueba: 3 corridas noise=low y 1 noise=medium.
La prediccion original se guarda en config/predicciones.txt.
'FIN' determina si se completo el recorrido.
La medicion real usa /sim/pose y es distinta de /odom.
La tolerancia de cierre real es <= 40 cm en 3B o 3C con low.
Ver resultados_parte_d.csv; las metricas dependen de los datos medidos.
Scripts cierre_real.py es auxiliar independiente, no codigo original del profesor.
