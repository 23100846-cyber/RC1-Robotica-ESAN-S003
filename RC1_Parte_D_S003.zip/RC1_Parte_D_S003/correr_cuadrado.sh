#!/usr/bin/env bash
set -uo pipefail
if [[ $# -ne 2 ]]; then echo 'Uso: ./correr_cuadrado.sh 3A low (o medium)'; exit 2; fi
PRUEBA="${1^^}"; NIVEL="${2,,}"
if [[ ! "$PRUEBA" =~ ^3[ABC]$ || ! "$NIVEL" =~ ^(low|medium)$ ]]; then echo 'ERROR: valores invalidos'; exit 2; fi
BASE="$HOME/RC1_Parte_D"; SRC="$HOME/scripts_pdi/scripts_pdi"
mkdir -p "$BASE"/{csv,plots,logs,config}
for i in 1 2 3; do
  NOM="${PRUEBA}_${NIVEL}_r${i}"
  if [[ ! -e "$BASE/csv/${NOM}_sim.csv" && ! -e "$BASE/csv/${NOM}_real.csv" ]]; then break; fi
done
if [[ -e "$BASE/csv/${NOM}_sim.csv" || -e "$BASE/csv/${NOM}_real.csv" ]]; then echo "ERROR: ya hay 3 corridas ${PRUEBA} ${NIVEL}. No se sobrescribe."; exit 1; fi
if [[ ! -f "$SRC/cuadrado_controller.py" || ! -f "$BASE/cierre_real.py" ]]; then echo 'ERROR: faltan scripts, revisa extraccion de KIT'; exit 1; fi
RUIDO="$(ros2 param get /yahboomcar_sim noise_level 2>&1)"
echo "Simulador: $RUIDO"
if ! grep -q "${NIVEL}" <<< "$RUIDO"; then echo "ERROR: esta corrida requiere noise=${NIVEL}, cambia el simulador desde Terminal 1"; exit 1; fi
if ! timeout 15s ros2 service call /sim/reset std_srvs/srv/Empty '{}' > "$BASE/logs/${NOM}_reset.txt" 2>&1; then echo 'ERROR: /sim/reset. Revisa el simulador'; exit 1; fi
sleep 1
cmd=(python3 -u cuadrado_controller.py --ros-args -p side:=2.0 -p linear_speed:=0.20 -p log_csv:="$BASE/csv/${NOM}_sim.csv")
if [[ "$PRUEBA" == '3A' ]]; then
 cmd+=(-p experimento:=cuadrado_abierto)
elif [[ "$PRUEBA" == '3B' ]]; then
 cmd+=(-p experimento:=cuadrado -p kp:=3.0 -p ki:=0.0 -p kd:=4.0 -p kp_yaw:=10.0 -p ki_yaw:=0.0 -p kd_yaw:=1.2 -p bias_w:=0.03)
else
 cmd+=(-p experimento:=cuadrado -p kp:=3.0 -p ki:=0.5 -p kd:=4.0 -p kp_yaw:=10.0 -p ki_yaw:=0.0 -p kd_yaw:=1.2 -p bias_w:=0.05)
fi
printf '%s\n' "${cmd[*]}" > "$BASE/logs/${NOM}_comando.txt"
REC_PID='' ; CTRL_PID=''
limpiar() {
  if [[ -n "$CTRL_PID" ]] && kill -0 "$CTRL_PID" 2>/dev/null; then kill -INT "$CTRL_PID" 2>/dev/null || :; fi
  if [[ -n "$REC_PID" ]] && kill -0 "$REC_PID" 2>/dev/null; then kill -INT "$REC_PID" 2>/dev/null || :; fi
  [[ -n "$CTRL_PID" ]] && wait "$CTRL_PID" 2>/dev/null || :
  [[ -n "$REC_PID" ]] && wait "$REC_PID" 2>/dev/null || :
}
trap limpiar EXIT
python3 -u "$BASE/cierre_real.py" --csv "$BASE/csv/${NOM}_real.csv" --png "$BASE/plots/${NOM}_real.png" --lado 2.0 > "$BASE/logs/${NOM}_real_terminal.txt" 2>&1 &
REC_PID=$!
sleep 1
if ! kill -0 "$REC_PID" 2>/dev/null; then echo 'ERROR: el registrador real no arranco'; exit 1; fi
pushd "$SRC" >/dev/null
"${cmd[@]}" > "$BASE/logs/${NOM}_controlador_terminal.txt" 2>&1 &
popd >/dev/null
CTRL_PID=$!
echo "CORRIDA $NOM: registrando /odom y /sim/pose. Puede durar aproximadamente un minuto."
FIN=0
for ((sec=0;sec<130;sec++)); do
 if grep -q 'FIN\. error de cierre' "$BASE/logs/${NOM}_controlador_terminal.txt" 2>/dev/null; then FIN=1; break; fi
 if ! kill -0 "$CTRL_PID" 2>/dev/null; then break; fi
 sleep 1
done
if [[ "$FIN" == '1' ]]; then echo "FIN encontrado ($NOM). Deteniendo registradores..."; sleep 1; else echo "ATENCION: sin FIN en 130 segundos o proceso interrumpido; se guardara la evidencia."; fi
limpiar
trap - EXIT
if [[ -s "$BASE/csv/${NOM}_sim.csv" && -s "$BASE/csv/${NOM}_real.csv" ]]; then
 grep 'FIN\. error de cierre' "$BASE/logs/${NOM}_controlador_terminal.txt" | tail -1 || :
 grep -E 'cierre segun|cierre según|cierre REAL' "$BASE/logs/${NOM}_real_terminal.txt" || :
 echo "Archivos guardados: ${NOM}_sim.csv y ${NOM}_real.csv"
else
 echo "ERROR: faltan CSV para $NOM. Revisa $BASE/logs"
 exit 1
fi
