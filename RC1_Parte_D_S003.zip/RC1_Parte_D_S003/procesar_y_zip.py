#!/usr/bin/env python3
import csv, math, shutil, subprocess, sys, re
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
home=Path.home(); base=home/'RC1_Parte_D'; src=home/'scripts_pdi/scripts_pdi'
nombres=[f'{p}_{n}_r{i}' for p in ('3A','3B','3C') for n,rep in (('low',3),('medium',1)) for i in range(1,rep+1)]
fallos=[n for n in nombres if not (base/f'csv/{n}_sim.csv').is_file() or not (base/f'csv/{n}_real.csv').is_file()]
if fallos:raise SystemExit('Faltan pruebas: '+', '.join(fallos))
res=[]
def closure_yaw(rows,xx,yy,th):
 a=[(float(r[xx]),float(r[yy]),float(r[th])) for r in rows]
 cierre=100*math.hypot(a[-1][0]-a[0][0],a[-1][1]-a[0][1]); yaw=sum(math.atan2(math.sin(b[2]-x[2]),math.cos(b[2]-x[2])) for x,b in zip(a,a[1:]))*180/math.pi
 return cierre,yaw
for n in nombres:
 sim=base/f'csv/{n}_sim.csv'; real=base/f'csv/{n}_real.csv'
 with sim.open(newline='') as f:r=list(csv.DictReader(f)); fields=r[0].keys() if r else []
 if not r:raise SystemExit(f'CSV vacio: {sim}')
 ix=next((i for i,row in enumerate(r) if row['estado']=='FIN'),None)
 clean=r[:ix+1] if ix is not None else r
 limpio=base/f'csv/{n}_sim_limpio.csv'
 with limpio.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(clean)
 with real.open(newline='') as f:rr=list(csv.DictReader(f))
 if not rr:raise SystemExit(f'CSV real vacio: {real}')
 co,yo=closure_yaw(clean,'x','y','yaw');cr,yr=closure_yaw(rr,'real_x','real_y','real_yaw')
 p=n.split('_')[0]
 cmd=[sys.executable,str(src/'09_plot_csv.py'),str(limpio),'--experimento','cuadrado_abierto' if p=='3A' else 'cuadrado','--lado','2.0']
 proc=subprocess.run(cmd,cwd=src,capture_output=True,text=True)
 (base/f'logs/{n}_metricas.txt').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8')
 if proc.returncode:raise SystemExit('ERROR graficando '+n+': '+proc.stderr)
 shutil.move(str(limpio.with_suffix('.png')),str(base/f'plots/{n}_sim.png'))
 row=dict(prueba=p,noise=n.split('_')[1],corrida=n.split('_')[2],terminado='SI' if ix is not None else 'NO',duracion_s=round(float(clean[-1]['t']),2),cierre_odom_cm=round(co,2),cierre_real_cm=round(cr,2),yaw_acum_odom_deg=round(yo,2),yaw_acum_real_deg=round(yr,2))
 res.append(row)
 (base/f'logs/{n}_resumen.txt').write_text('\n'.join(f'{k}: {v}' for k,v in row.items())+'\n',encoding='utf-8')
 print(n, 'FIN' if ix is not None else 'SIN FIN', 'odom',round(co,1),'cm','REAL',round(cr,1),'cm','yaw real',round(yr,1),'deg')
out=base/'resultados_parte_d.csv'
with out.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=res[0].keys());w.writeheader();w.writerows(res)
readme='''UNIVERSIDAD ESAN - RC-1 - PARTE D - S003
Experimento 3: cuadrado 2 x 2 m, en simulador.
3A: lazo abierto; 3B: odometria + PID, bias_w=0.03;
3C: PID + Ki=0.5, bias_w=0.05.
Ganancias 3B/3C: linea Kp=3,Kd=4; giro Kp_yaw=10,Kd_yaw=1.2.
Por prueba: 3 corridas noise=low y 1 noise=medium.
La prediccion original se guarda en config/predicciones.txt.
'FIN' determina si se completo el recorrido.
La medicion real usa /sim/pose y es distinta de /odom.
La tolerancia de cierre real es <= 40 cm en 3B o 3C con low.
Ver resultados_parte_d.csv; las metricas dependen de los datos medidos.
Scripts cierre_real.py es auxiliar independiente, no codigo original del profesor.
'''
(base/'README.txt').write_text(readme,encoding='utf-8')
(base/'scripts').mkdir(exist_ok=True)
for fn in ('cuadrado_controller.py','core_cuadrado.py','core_pid.py','09_plot_csv.py'):
 if not (src/fn).is_file():raise SystemExit('Falta fuente: '+fn)
 shutil.copy2(src/fn,base/'scripts'/fn)
zipf=home/'RC1_Parte_D_S003.zip'
with ZipFile(zipf,'w',ZIP_DEFLATED) as z:
 for p in sorted(base.rglob('*')):
  if p.is_file():z.write(p,Path('RC1_Parte_D_S003')/p.relative_to(base))
with ZipFile(zipf) as z:
 bad=z.testzip()
 if bad:raise SystemExit('ZIP corrupto: '+bad)
 print('ZIP CREADO CORRECTAMENTE:',zipf,'archivos:',len(z.namelist()))
print('Revisar resultados antes de declarar superada la Parte D.')
