UNIVERSIDAD ESAN - ROBOTICA
RC-1 CONTROL PID
PARTE B - PRUEBA 1B: SOLO P
SECCION S-003

OBJETIVO:
Comparar distintas ganancias Kp manteniendo
Ki = 0.0 y Kd = 0.0.

CONFIGURACION:
Experimento: recta de 2 m
line_offset: 0.10 m
bias_w: 0.06 rad/s
noise: low

RESULTADOS:

KP = 1.0
Duracion: 10.3 s
Error medio: 5.11 cm
Error maximo: 10.00 cm
Error final: 5.07 cm
Asentamiento: No
Estado: Completado

KP = 3.0
Duracion: 11.4 s
Error medio: 9.50 cm
Error maximo: 22.14 cm
Error final: 9.11 cm
Asentamiento: No
Estado: Completado

KP = 4.0
Tiempo registrado: 117.47 s
Ultimo error lateral: 61.48 cm
Asentamiento: No
Estado: No completado

CONCLUSION:
Kp = 1.0 obtuvo los menores errores en las
corridas completadas.

Kp = 3.0 presento mayores oscilaciones.

Kp = 4.0 produjo giros repetitivos y
no consiguio completar el recorrido.

El control proporcional por si solo no
consiguio mantener el error dentro de
la banda de +/-2 cm hasta finalizar.

NOTA:
Los CSV originales se conservaron.
Los CSV limpios excluyen las filas FIN repetidas.
El script 09_plot_csv.py se utiliza para
analizar y graficar los resultados.
