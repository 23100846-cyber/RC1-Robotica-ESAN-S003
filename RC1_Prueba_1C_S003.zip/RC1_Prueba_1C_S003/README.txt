UNIVERSIDAD ESAN - ROBOTICA
RC-1 - PARTE B
PRUEBA 1C: CONTROL P + D
SECCION S-003

OBJETIVO:
Comparar el control proporcional-derivativo
y estudiar la reduccion de oscilaciones.

CONDICIONES:
Experimento: recta de 2 metros
Ruido: low
line_offset: 0.10 m
bias_w: 0.06 rad/s
Ki: 0.0

===============================
CORRIDA 1 - KP 3.0, KD 4.0
===============================
===== PRUEBA 1C - KP 3.0 KD 4.0 =====
Muestras originales: 2534
Muestras validas: 307
Duracion: 10.24 s
Error medio: 3.12 cm
Error maximo: 10.00 cm
Error final: 2.12 cm
Asentamiento: No se asienta
CSV limpio: /home/andyf/RC1_Parte_B/csv/exp1c_kp3_kd4_limpio.csv


===============================
CORRIDA 2 - KP 1.0, KD 4.0
===============================
===== PRUEBA 1C - KP 1.0 KD 4.0 =====
Muestras originales: 522
Muestras validas: 306
Duracion: 10.20 s
Error medio: 7.72 cm
Error maximo: 10.00 cm
Error final: 6.29 cm
Asentamiento: No se asienta
CSV limpio: /home/andyf/RC1_Parte_B/csv/exp1c_kp1_kd4_limpio.csv


CONCLUSION:
La combinacion Kp=3.0 y Kd=4.0 obtuvo
un menor error lateral final que
Kp=1.0 y Kd=4.0.

Con Kp=3.0 y Kd=4.0 se obtuvo:
Error medio: 3.12 cm
Error final: 2.12 cm

El componente derivativo redujo las
oscilaciones respecto al controlador
proporcional con Kp=3.0 de la prueba 1B.

Ninguna de las dos corridas logro
asentarse permanentemente en +/-2 cm.

CONFIGURACION SELECCIONADA PARA 1D:
Kp = 3.0
Kd = 4.0
Ki = 0.0 (antes de agregar accion integral)

Se conservan los CSV originales y limpios.
