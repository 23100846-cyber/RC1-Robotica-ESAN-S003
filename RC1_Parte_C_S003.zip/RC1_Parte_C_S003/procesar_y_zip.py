#!/usr/bin/env python3
import csv
import math
import shutil
import subprocess
import sys
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import numpy as np

home = Path.home()
base = home / "RC1_Parte_C"
scripts = home / "scripts_pdi/scripts_pdi"
pruebas = {
    "2a": (1.0, 0.0, 0.0), "2b": (10.0, 0.0, 0.0),
    "2c": (10.0, 1.2, 0.0), "2d": (3.0, 0.0, 0.0),
    "2e": (3.0, 0.4, 0.0), "2f": (3.0, 0.4, 0.1),
}

faltan = [n for n in pruebas if not (base / f"csv/{n}_original.csv").is_file()]
if faltan:
    raise SystemExit("Faltan corridas: " + ", ".join(faltan))

resumen = []
for nombre, (kp, kd, ki) in pruebas.items():
    origen = base / f"csv/{nombre}_original.csv"
    with origen.open(newline="") as f:
        rd = csv.DictReader(f)
        campos = rd.fieldnames
        filas = list(rd)
    if not filas:
        raise SystemExit(f"ERROR: CSV vacio: {origen}")
    fin = next((i for i, r in enumerate(filas) if r["estado"] == "FIN"), None)
    validas = filas[:fin+1] if fin is not None else filas
    limpio = base / f"csv/{nombre}_limpio.csv"
    with limpio.open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=campos)
        wr.writeheader()
        wr.writerows(validas)

    t = np.array([float(r["t"]) for r in validas])
    yaw_rad = np.unwrap(np.array([float(r["yaw"]) for r in validas]))
    yaw_deg = np.degrees(yaw_rad - yaw_rad[0])
    errores = np.abs(90.0 - yaw_deg)
    sobreimpulso = max(0.0, float(yaw_deg.max()) - 90.0) / 90.0 * 100.0
    asentamiento = next(
        (float(t[i]) for i in range(len(t)) if np.all(errores[i:] <= 2.0)),
        None,
    )
    terminado = fin is not None
    error_final = float(errores[-1]) if terminado else None
    observado = float(errores[-1])
    fila = {
        "prueba": nombre, "kp_yaw": kp, "kd_yaw": kd, "ki_yaw": ki,
        "terminado": "SI" if terminado else "NO",
        "muestras_validas": len(validas), "duracion_s": f"{t[-1]:.3f}",
        "sobreimpulso_pct": f"{sobreimpulso:.2f}",
        "t_asentamiento_2deg_s": f"{asentamiento:.3f}" if terminado and asentamiento is not None else "",
        "error_final_deg": f"{error_final:.2f}" if terminado else "",
        "ultimo_error_observado_deg": f"{observado:.2f}",
    }
    resumen.append(fila)

    lines = [f"PRUEBA {nombre} - GIRO +90 grados", f"Kp_yaw={kp}, Kd_yaw={kd}, Ki_yaw={ki}",
             f"Muestras originales: {len(filas)}", f"Muestras validas: {len(validas)}",
             f"Duracion observada: {t[-1]:.3f} s", f"Terminado: {fila['terminado']}",
             f"Sobreimpulso: {sobreimpulso:.2f} %",
             f"Asentamiento en +/-2 grados: {fila['t_asentamiento_2deg_s'] or 'No confirmado'}",
             f"Error final: {fila['error_final_deg'] + ' grados' if terminado else 'No disponible: no hubo FIN'}",
             f"Ultimo error observado: {observado:.2f} grados"]
    (base / f"logs/{nombre}_resumen.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    cmd = [sys.executable, str(scripts / "09_plot_csv.py"), str(limpio), "--experimento", "giro90"]
    proc = subprocess.run(cmd, capture_output=True, text=True, cwd=scripts)
    (base / f"logs/{nombre}_metricas.txt").write_text(proc.stdout + proc.stderr, encoding="utf-8")
    if proc.returncode != 0:
        raise SystemExit(f"Error al graficar {nombre}:\n{proc.stderr}")
    shutil.move(str(limpio.with_suffix(".png")), str(base / f"plots/{nombre}.png"))
    print(f"{nombre}: {'FIN' if terminado else 'SIN FIN'}, sobreimpulso={sobreimpulso:.2f} %, "
          f"asentamiento={fila['t_asentamiento_2deg_s'] or 'no'}, "
          f"error_final={fila['error_final_deg'] or 'no disponible'} deg")

resultados = base / "resultados_parte_c.csv"
with resultados.open("w", newline="") as f:
    wr = csv.DictWriter(f, fieldnames=list(resumen[0]))
    wr.writeheader()
    wr.writerows(resumen)

pred = base / "config/predicciones.txt"
if not pred.is_file():
    raise SystemExit("Falta config/predicciones.txt")

readme = """UNIVERSIDAD ESAN - RC-1 - PARTE C - SECCION S003
Experimento 2: giro +90 grados (simulador yahboomcar_sim, noise=low).

Se realizaron las pruebas obligatorias 2a, 2b y 2c y tres
combinaciones adicionales 2d, 2e y 2f.
Los parametros corresponden al PID angular, no al PID de la recta.

METODO:
- Reiniciar /sim/reset antes de cada prueba.
- Ejecutar cuadrado_controller.py con experimento=giro90.
- Si no hay FIN en el plazo del ensayo, conservar CSV como no completado.
- Conservar datos hasta el PRIMER FIN: despues aparecen filas FIN repetidas.
- Sobreimpulso porcentual = max(0, yaw_max - 90)/90 * 100.
- Asentamiento: primer tiempo desde el cual permanece en +/-2 grados
  hasta el final de la corrida; no se confirma si no hay FIN.
- Error final: |90 - yaw_final|, solo para corridas con FIN.

ARCHIVOS:
config/predicciones.txt: hipotesis anteriores a las pruebas.
resultados_parte_c.csv: resumen conjunto.
csv/: datos originales y limpios por corrida.
plots/: seis curvas del giro.
logs/: salida de terminal, metricas y resumen por corrida.
scripts/: codigo fuente original usado y scripts de procesamiento.

IMPORTANTE: estas son corridas del SIMULADOR, no del robot fisico.
Revisar las graficas para decidir que combinacion es mas rapida,
sin sobreimpulso significativo y con asentamiento confirmado.
"""
(base / "README.txt").write_text(readme, encoding="utf-8")

zip_path = home / "RC1_Parte_C_S003.zip"
if zip_path.exists():
    raise SystemExit(f"ZIP ya existe, no lo sobrescribo: {zip_path}")
with ZipFile(zip_path, "w", ZIP_DEFLATED) as z:
    for f in sorted(base.rglob("*")):
        if f.is_file():
            z.write(f, f"RC1_Parte_C_S003/{f.relative_to(base)}")
    for nombre in ("cuadrado_controller.py", "core_cuadrado.py", "core_pid.py", "09_plot_csv.py"):
        f = scripts / nombre
        if not f.is_file():
            raise SystemExit("Falta codigo original: " + str(f))
        z.write(f, f"RC1_Parte_C_S003/scripts/{nombre}")
with ZipFile(zip_path) as z:
    bad = z.testzip()
    count = len(z.namelist())
if bad:
    raise SystemExit("ZIP corrupto: " + bad)
print(f"ZIP creado y verificado: {zip_path} ({count} archivos)")
