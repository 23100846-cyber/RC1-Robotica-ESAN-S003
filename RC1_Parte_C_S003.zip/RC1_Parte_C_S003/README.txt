UNIVERSIDAD ESAN - RC-1 - PARTE C - SECCION S003
Experimento 2: giro +90 grados (simulador yahboomcar_sim, noise=low).

Se realizaron las pruebas obligatorias 2a, 2b y 2c y tres
combinaciones adicionales 2d, 2e y 2f.
Los parametros corresponden al PID angular, no al PID de la recta.

METODO:
- Reiniciar /sim/reset antes de cada prueba.
- Ejecutar cuadrado_controller.py con experimento=giro90.
- Si no hay FIN en el plazo del ensayo, conservar CSV como no completado.
- Conservar datos hasta el PRIMER FIN: despues aparecen filas FIN repetidas.
- Sobreimpulso porcentual = max(0, yaw_max - 90)/90 * 100.
- Asentamiento: primer tiempo desde el cual permanece en +/-2 grados
  hasta el final de la corrida; no se confirma si no hay FIN.
- Error final: |90 - yaw_final|, solo para corridas con FIN.

ARCHIVOS:
config/predicciones.txt: hipotesis anteriores a las pruebas.
resultados_parte_c.csv: resumen conjunto.
csv/: datos originales y limpios por corrida.
plots/: seis curvas del giro.
logs/: salida de terminal, metricas y resumen por corrida.
scripts/: codigo fuente original usado y scripts de procesamiento.

IMPORTANTE: estas son corridas del SIMULADOR, no del robot fisico.
Revisar las graficas para decidir que combinacion es mas rapida,
sin sobreimpulso significativo y con asentamiento confirmado.
