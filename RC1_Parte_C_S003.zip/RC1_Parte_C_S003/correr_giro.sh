#!/usr/bin/env bash
set -uo pipefail
if [[ $# -ne 4 ]]; then
  echo 'Uso: correr_giro.sh 2a 1.0 0.0 0.0  (nombre kp_yaw kd_yaw ki_yaw)'
  exit 2
fi
nombre="$1"; kp="$2"; kd="$3"; ki="$4"
base="$HOME/RC1_Parte_C"
original="$base/csv/${nombre}_original.csv"
log="$base/logs/${nombre}_terminal.txt"
if [[ -e "$original" ]]; then
  echo "ERROR: $original ya existe; no se sobrescribira."
  exit 1
fi
cd "$HOME/scripts_pdi/scripts_pdi" || exit 1
printf '\n===== %s: Kp=%s, Kd=%s, Ki=%s =====\n' "$nombre" "$kp" "$kd" "$ki"
echo 'Reiniciando el simulador...'
if ! timeout 12s ros2 service call /sim/reset std_srvs/srv/Empty '{}' > "$base/logs/${nombre}_reset.txt" 2>&1; then
  echo 'ERROR en /sim/reset. Revisa la Terminal 1 y la Terminal 2.'
  exit 1
fi
sleep 1
echo 'Giro en marcha; se detendra automaticamente al superar ~15 s.'
timeout --signal=INT --kill-after=3s 18s python3 -u cuadrado_controller.py --ros-args \
  -p experimento:=giro90 \
  -p kp_yaw:="$kp" -p kd_yaw:="$kd" -p ki_yaw:="$ki" \
  -p log_csv:="$original" 2>&1 | tee "$log"
if [[ -f "$original" ]] && grep -q ',FIN' "$original"; then
  echo "OK: $nombre tiene FIN."
elif [[ -s "$original" ]]; then
  echo "ATENCION: $nombre no llego a FIN; conservar como prueba sin asentamiento."
else
  echo "ERROR: no se genero un CSV valido para $nombre."
fi
