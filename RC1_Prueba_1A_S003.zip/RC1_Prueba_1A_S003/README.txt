UNIVERSIDAD ESAN
RC-1 - PARTE B - PRUEBA 1A
SECCION S003

EXPERIMENTO: RECTA DE 2 METROS
CONTROLADOR: BANG-BANG

EVIDENCIAS:
- CSV original del experimento.
- Grafica de trayectoria y error lateral.
- Codigo fuente utilizado.

Los archivos originales se conservaron.
